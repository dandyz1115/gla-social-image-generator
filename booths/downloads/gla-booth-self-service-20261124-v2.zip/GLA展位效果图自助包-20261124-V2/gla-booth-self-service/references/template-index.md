# 展位模板索引

| 页面规格 | 模板 | 结构图 | 完整提示词 |
|---|---|---|---|
| 3×3m | 3×3m 常规标展 | [JPG](../assets/templates/33-standard.jpg) | [TXT](prompts/33-standard.txt) |
| 3×3m | 3×3m 单背墙三面开放 | [JPG](../assets/templates/33-three-open.jpg) | [TXT](prompts/33-three-open.txt) |
| 3×3m | 3×3m 双品牌转角 | [JPG](../assets/templates/33-corner-joint.jpg) | [TXT](prompts/33-corner-joint.txt) |
| 3×3m | 3×3m 高机位标展 | [JPG](../assets/templates/33-high.jpg) | [TXT](prompts/33-high.txt) |
| 6×3m | 6×3m 双前台标展 | [JPG](../assets/templates/63-standard.jpg) | [TXT](prompts/63-standard.txt) |
| 6×3m | 6×3m 高机位标展 | [JPG](../assets/templates/63-standard-high.jpg) | [TXT](prompts/63-standard-high.txt) |
| 6×3m | 6×3m 特展 Option 1 · 直线门楣 | [JPG](../assets/templates/63-custom-1.jpg) | [TXT](prompts/63-custom-1.txt) |
| 6×3m | 6×3m 特展 Option 2 · 转角 | [JPG](../assets/templates/63-custom-2.jpg) | [TXT](prompts/63-custom-2.txt) |
| 6×3m | 6×3m 特展 Option 3 · 正面 | [JPG](../assets/templates/63-custom-3-front.jpg) | [TXT](prompts/63-custom-3-front.txt) |
| 6×3m | 6×3m 特展 Option 3 · 斜前透视 | [JPG](../assets/templates/63-custom-3-perspective.jpg) | [TXT](prompts/63-custom-3-perspective.txt) |
| 6×3m | 6×3m 特展 Option 3 · 俯视 | [JPG](../assets/templates/63-custom-3-overhead.jpg) | [TXT](prompts/63-custom-3-overhead.txt) |
| 6×6m | 6×6m 高机位标展 | [JPG](../assets/templates/66-standard.jpg) | [TXT](prompts/66-standard.txt) |
| 6×6m | 6×6m 特展 Option 1 · 顶棚格栅 | [JPG](../assets/templates/66-custom-1.jpg) | [TXT](prompts/66-custom-1.txt) |
| 6×6m | 6×6m 特展 Option 2 · 弧形展墙 | [JPG](../assets/templates/66-custom-2.jpg) | [TXT](prompts/66-custom-2.txt) |
| 6×6m | 6×6m 特展 Option 3 · 左侧开放 | [JPG](../assets/templates/66-custom-3.jpg) | [TXT](prompts/66-custom-3.txt) |
| 6×6m | 6×6m 特展 Option 4 · 转角门楣 | [JPG](../assets/templates/66-custom-4.jpg) | [TXT](prompts/66-custom-4.txt) |
| 6×6m | 6×6m 特展 · 流线飘带 | [JPG](../assets/templates/66-alt-ribbon.jpg) | [TXT](prompts/66-alt-ribbon.txt) |
| 6×6m | 6×6m 特展 · 折线门框 | [JPG](../assets/templates/66-alt-angular.jpg) | [TXT](prompts/66-alt-angular.txt) |
| 6×6m | 6×6m 特展 · 波浪格栅 | [JPG](../assets/templates/66-alt-wave.jpg) | [TXT](prompts/66-alt-wave.txt) |
| 6×6m | 6×6m 沙发参考 Option 1 · 顶棚格栅 | [JPG](../assets/templates/66-sofa-1.jpg) | [TXT](prompts/66-sofa-1.txt) |
| 6×6m | 6×6m 沙发参考 Option 2 · 弧形展墙 | [JPG](../assets/templates/66-sofa-2.jpg) | [TXT](prompts/66-sofa-2.txt) |
| 6×6m | 6×6m 沙发参考 Option 3 · 左侧开放 | [JPG](../assets/templates/66-sofa-3.jpg) | [TXT](prompts/66-sofa-3.txt) |
| 6×6m | 6×6m 沙发参考 Option 4 · 转角门楣 | [JPG](../assets/templates/66-sofa-4.jpg) | [TXT](prompts/66-sofa-4.txt) |
| 9×3m | 9×3m 高机位标展 | [JPG](../assets/templates/93-standard-high.jpg) | [TXT](prompts/93-standard-high.txt) |

[局部修图提示词](prompts/fixes.txt)
